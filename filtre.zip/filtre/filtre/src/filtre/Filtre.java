/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filtre;


public class Filtre {

    public static NewJFrame f1 = new NewJFrame();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        f1.show();
            
    }
    
}
